package com.example.sandy.eightball;

/**
 * Created by sandy on 06/11/2016.
 */

public interface Answerable {
    String getAnswer();
}
