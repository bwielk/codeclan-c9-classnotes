var React = require('react');

var CountryDetail = React.createClass( {
  render: function(){
      return (
          <h3>
            Country details to go here.
          </h3>
        );
    }
});

module.exports = CountryDetail;
