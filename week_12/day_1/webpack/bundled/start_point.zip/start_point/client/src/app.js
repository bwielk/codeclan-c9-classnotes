var UI = require('./views/ui');

var app = function(){
  new UI();
}

window.onload = app;
