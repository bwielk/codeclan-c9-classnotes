var app = function(){
  new UI();
}

window.onload = app;
