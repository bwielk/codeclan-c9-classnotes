var Review = function(options){
  this.comment = options.comment;
  this.rating = options.rating;
}